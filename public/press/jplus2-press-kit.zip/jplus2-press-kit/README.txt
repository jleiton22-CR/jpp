jplus2 press kit
================

Contents: icon/ (PNG, 1024 px, light and dark), screenshots/ (JPG, 1500 px wide, light and dark), this file.
Updated: 2026-11-16


ENGLISH
-------

QUICK FACTS
- Name: jplus2 (always lowercase)
- Developer: Jason Leiton, one developer
- What it is: A native code editor for macOS (Cocoa), built on the Scintilla 5 editing component
- Platforms: macOS 12 or later, Apple silicon and Intel. An iPadOS version is planned for the next release; details may change.
- Editions: jplus2 Lite: free download, about 5.6 MB, version 1.0.1. / jplus2 (full): coming to the Mac App Store, planned price $19.99.
- Languages: Syntax colouring and code folding for 95 languages
- Lite includes: Tabs and session restore, find and replace with regular expressions, macros, bookmarks, a file explorer, Go to Anything, a command palette, a minimap, and light and dark appearance
- The full version adds: IntelliSense, compile and run, a Python debugger, SQL (Databricks, Snowflake, SQLite, Excel and CSV files), GitHub, an AI assistant with an Agent mode that proposes file changes and terminal commands for your approval (Claude with your own API key, OpenAI-compatible services or local models such as Ollama) and a built-in guide in English and Spanish
- Privacy: No account and no analytics. Lite makes no network connections of its own. API keys are kept in the macOS Keychain.
- Licence: Proprietary; Lite is free. Scintilla and Lexilla are © Neil Hodgson and used under their own licence.
- Website: https://jplus2.com
- Contact: leiton@live.com

DESCRIPTIONS YOU CAN COPY

One line:
jplus2 is a fast, native code editor for Mac, with a free Lite version.

Short (about 60 words):
jplus2 is a native code editor for macOS, built on Scintilla 5 for Apple silicon and Intel Macs. The free Lite version covers everyday editing in 95 languages, with no account and no telemetry. The full version, coming to the Mac App Store, adds run and debug, SQL on CSV and Excel files, GitHub and an AI assistant that uses your own API key or a local model.

Long (about 110 words):
jplus2 is a native code editor for macOS, written in Cocoa on top of the Scintilla 5 editing component and made by one developer, Jason Leiton. The free Lite version, a download of about 5.6 MB, gives syntax colouring and folding for 95 languages, tabs with session restore, find and replace with regular expressions, macros, bookmarks, a file explorer, Go to Anything, a command palette and a minimap, with no account and no telemetry. The full version, coming to the Mac App Store, adds IntelliSense, compile and run, a Python debugger, SQL on databases and on Excel or CSV files, GitHub integration and an AI assistant that works with your own Claude API key, an OpenAI-compatible service or a local model. An iPadOS version is planned.

BRAND NOTES
- Write the name as jplus2, all lowercase, even at the start of a sentence. Call the free edition jplus2 Lite.
- Use the icon as supplied, without changing its colours, proportions or the J and 2.
- Please link to jplus2.com.
- Site colours: indigo #4257f5, violet #6a3de8, coral #ef6f6c, text #1d1d1f.

GOOD TO KNOW BEFORE YOU WRITE
- jplus2 is version 1.0 from a single developer, and it is closed source. There is no plugin system.
- The full version is not on the Mac App Store yet. Today only jplus2 Lite can be downloaded.
- The Lite installer is not yet notarized by Apple, so macOS asks you to confirm opening it: System Settings ▸ Privacy & Security ▸ Open Anyway.
- Comparisons on this site cite each vendor's own pages and say when they were checked.

ESPAÑOL
-------

DATOS RÁPIDOS
- Nombre: jplus2 (siempre en minúsculas)
- Desarrollador: Jason Leiton, un solo desarrollador
- Qué es: Un editor de código nativo para macOS (Cocoa), basado en el componente de edición Scintilla 5
- Plataformas: macOS 12 o posterior, Apple Silicon e Intel. Una versión para iPadOS está planeada para el próximo lanzamiento; los detalles pueden cambiar.
- Ediciones: jplus2 Lite: descarga gratis, unos 5.6 MB, versión 1.0.1. / jplus2 (completa): llega al Mac App Store, precio previsto $19.99.
- Lenguajes: Resaltado de sintaxis y plegado de código para 95 lenguajes
- Lite incluye: Pestañas y restauración de la sesión, buscar y reemplazar con expresiones regulares, macros, marcadores, un explorador de archivos, Ir a cualquier cosa, una paleta de comandos, un minimapa y apariencia clara y oscura
- La versión completa añade: IntelliSense, compilar y ejecutar, un depurador de Python, SQL (Databricks, Snowflake, SQLite y archivos de Excel y CSV), GitHub, un asistente de IA con modo Agente que propone cambios en archivos y comandos de terminal para tu aprobación (Claude con tu propia clave de API, servicios compatibles con OpenAI o modelos locales como Ollama) y una guía integrada en inglés y español
- Privacidad: Sin cuenta y sin analíticas. Lite no hace conexiones de red por su cuenta. Las claves de API se guardan en el Llavero de macOS.
- Licencia: Propietaria; Lite es gratis. Scintilla y Lexilla son © Neil Hodgson y se usan bajo su propia licencia.
- Sitio web: https://jplus2.com
- Contacto: leiton@live.com

DESCRIPCIONES QUE PUEDES COPIAR

Una línea:
jplus2 es un editor de código rápido y nativo para Mac, con una versión Lite gratis.

Corta (unas 60 palabras):
jplus2 es un editor de código nativo para macOS, basado en Scintilla 5 para Mac con Apple Silicon e Intel. La versión Lite, gratis, cubre la edición diaria en 95 lenguajes, sin cuenta y sin telemetría. La versión completa, que llega al Mac App Store, añade ejecutar y depurar, SQL sobre archivos CSV y Excel, GitHub y un asistente de IA que usa tu propia clave de API o un modelo local.

Larga (unas 110 palabras):
jplus2 es un editor de código nativo para macOS, escrito en Cocoa sobre el componente de edición Scintilla 5 y hecho por un solo desarrollador, Jason Leiton. La versión Lite, gratis y de unos 5.6 MB, ofrece resaltado de sintaxis y plegado para 95 lenguajes, pestañas con restauración de la sesión, buscar y reemplazar con expresiones regulares, macros, marcadores, un explorador de archivos, Ir a cualquier cosa, una paleta de comandos y un minimapa, sin cuenta y sin telemetría. La versión completa, que llega al Mac App Store, añade IntelliSense, compilar y ejecutar, un depurador de Python, SQL sobre bases de datos y sobre archivos de Excel o CSV, integración con GitHub y un asistente de IA que funciona con tu propia clave de Claude, un servicio compatible con OpenAI o un modelo local. Hay una versión para iPadOS planeada.

NORMAS DE MARCA
- Escribe el nombre como jplus2, todo en minúsculas, incluso al principio de una frase. A la edición gratuita llámala jplus2 Lite.
- Usa el icono tal como se entrega, sin cambiar sus colores, proporciones ni la J y el 2.
- Enlaza, por favor, a jplus2.com.
- Colores del sitio: índigo #4257f5, violeta #6a3de8, coral #ef6f6c, texto #1d1d1f.

CONVIENE SABER ANTES DE ESCRIBIR
- jplus2 es la versión 1.0 de un solo desarrollador y es de código cerrado. No tiene sistema de complementos.
- La versión completa aún no está en el Mac App Store. Hoy solo se puede descargar jplus2 Lite.
- El instalador de Lite aún no está notarizado por Apple, así que macOS pide confirmar que lo abras: Ajustes del Sistema ▸ Privacidad y seguridad ▸ Abrir igualmente.
- Las comparaciones de este sitio citan las páginas de cada fabricante y dicen cuándo se consultaron.
